package com.imejpul.auxiliares;

public enum  LadoCurva {
    DERECHA, IZQUIERDA
}


